<!DOCTYPE html>
<html>
<head>
	<title>Karyawan DTP</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<h3>Edit Pegawai</h3>

		<a href="/pegawai"> Kembali</a>

		<br/>
		<br/>

		<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<form action="/pegawai/update" method="post">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="id" value="<?php echo e($p->id_karyawan); ?>"> <br/>
			<table class="table">
				<!-- Pegawai -->
				<tr>
					<td><h4>Profile</h4></td>
				</tr>

				<tr>
					<td>Nama</td>
					<td>:</td>
					<td><input type="text" name="nama" value="<?php echo e($p->nama); ?>" required="required"></td>
				</tr>

				<tr>
					<td>Alamat</td>
					<td>:</td>
					<td><textarea name="alamat" required="required"><?php echo e($p->alamat); ?></textarea></td>
				</tr>

				<tr>
					<td>No KTP</td>
					<td>:</td>
					<td><input type="text" name="no_ktp" value="<?php echo e($p->no_ktp); ?>" required="required"></td>
				</tr>
				<!-- Pegawai -->


				<!-- Pendidikan -->
				<tr>
					<td><h4>Pendidikan</h4></td>
				</tr>

				<tr>
					<td>Nama Sekolah / Universitas</td>
					<td>:</td>
					<td><input type="text" name="nama_sekolah" value="<?php echo e($p->nama_sekolah); ?>" required="required"></td>

					<td>Jurusan</td>
					<td>:</td>
					<td><input type="text" name="jurusan" value="<?php echo e($p->jurusan); ?>" required="required"></td>

					<td>Tahun Masuk</td>
					<td>:</td>
					<td><input type="text" name="thn_masuk" value="<?php echo e($p->thn_masuk); ?>" required="required"></td>

					<td>Tahun Lulus</td>
					<td>:</td>
					<td><input type="text" name="thn_lulus" value="<?php echo e($p->thn_lulus); ?>" required="required"></td>
				</tr>
				<!-- Pendidikan -->


				<!-- Pendidikan -->
				<tr>
					<td><h4>Pengalaman Kerja</h4></td>
				</tr>

				<tr>
					<td>Perusahaan</td>
					<td>:</td>
					<td><input type="text" name="instansi" value="<?php echo e($p->instansi); ?>" required="required"></td>

					<td>Jabatan</td>
					<td>:</td>
					<td><input type="text" name="jabatan" value="<?php echo e($p->jabatan); ?>" required="required"></td>

					<td>Tahun</td>
					<td>:</td>
					<td><input type="text" name="tahun" value="<?php echo e($p->tahun); ?>" required="required"></td>

					<td>Keterangan</td>
					<td>:</td>
					<td><textarea name="keterangan" required="required"><?php echo e($p->keterangan); ?></textarea></td>
				</tr>
				<!-- Pendidikan -->
			</table>


			<input type="submit" value="Simpan Data">
		</form>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
	</div>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/karyawan_dtp/resources/views/edit.blade.php ENDPATH**/ ?>