<!DOCTYPE html>
<html>
<head>
	<title>Karyawan DTP</title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
		<h3>Data Pegawai</h3>

		<a class="btn btn-primary" href="/pegawai/tambah"> + Tambah Baru</a>

		<br/>
		<br/>

		<table class="table table-bordered table-striped table-responsive">
			<tr class="text-center">
				<th colspan="4" class="bg-info">Profile</th>
			
				<th colspan="4" class="bg-success">Pendidikan Terakhir</th>

				<th colspan="5" class="bg-primary">Pengalaman Kerja Terakhir</th>
			</tr>
			<tr>
				<th>ID Karyawan</th>
				<th>Nama</th>
				<th>Alamat</th>
				<th>No KTP</th>

				<th>Instansi Pendidikan</th>
				<th>Jurusan</th>
				<th>Tahun Masuk</th>
				<th>Tahun Lulus</th>

				<th>Instansi Perusahaan</th>
				<th>Jabatan</th>
				<th>Tahun</th>
				<th>Keterangan</th>
				<th>Opsi</th>
			</tr>
			<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($p->id_karyawan); ?></td>
				<td><?php echo e($p->nama); ?></td>
				<td><?php echo e($p->alamat); ?></td>
				<td><?php echo e($p->no_ktp); ?></td>

				<td><?php echo e($p->nama_sekolah); ?></td>
				<td><?php echo e($p->jurusan); ?></td>
				<td><?php echo e($p->thn_masuk); ?></td>
				<td><?php echo e($p->thn_lulus); ?></td>


				<td><?php echo e($p->instansi); ?></td>
				<td><?php echo e($p->jabatan); ?></td>
				<td><?php echo e($p->tahun); ?></td>
				<td><?php echo e($p->keterangan); ?></td>


				<td>
					<a class="btn btn-warning col-12" href="/pegawai/edit/<?php echo e($p->id_karyawan); ?>">Edit</a>
					
					<a class="btn btn-danger col-12" href="/pegawai/hapus/<?php echo e($p->id_karyawan); ?>">Hapus</a>
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/karyawan_dtp/resources/views/index.blade.php ENDPATH**/ ?>