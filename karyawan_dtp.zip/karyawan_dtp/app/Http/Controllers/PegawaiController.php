<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class PegawaiController extends Controller
{
	public function index()
	{
    	// mengambil data dari table pegawai
		$pegawai = DB::table('pegawai')
		->join('pendidikan','pendidikan.id_karyawan','=','pegawai.id_karyawan')
		->join('pengalaman_kerja','pengalaman_kerja.id_karyawan','=','pegawai.id_karyawan')
		->get();

    	// mengirim data pegawai ke view index
		return view('index',['pegawai' => $pegawai]);

	}

	public function tambah()
	{

	// memanggil view tambah
		return view('tambah');

	}

	public function store(Request $request)
	{
	// insert data ke table pegawai
		DB::table('pegawai')->insert([
			'id_karyawan' => $request->id_karyawan,
			'nama' => $request->nama,
			'alamat' => $request->alamat,
			'no_ktp' => $request->no_ktp
		]);

		DB::table('pendidikan')->insert([
			'id_karyawan' => $request->id_karyawan,
			'nama_sekolah' => $request->nama_sekolah,
			'jurusan' => $request->jurusan,
			'thn_masuk' => $request->thn_masuk,
			'thn_lulus' => $request->thn_lulus
		]);

		DB::table('pengalaman_kerja')->insert([
			'id_karyawan' => $request->id_karyawan,
			'instansi' => $request->instansi,
			'jabatan' => $request->jabatan,
			'tahun' => $request->tahun,
			'keterangan' => $request->keterangan
		]);
	// alihkan halaman ke halaman pegawai
		return redirect('/pegawai');

	}

	// method untuk edit data pegawai
	public function edit($id)
	{
	// mengambil data pegawai berdasarkan id yang dipilih
		$pegawai = DB::table('pegawai')
		->join('pendidikan','pendidikan.id_karyawan','=','pegawai.id_karyawan')
		->join('pengalaman_kerja','pengalaman_kerja.id_karyawan','=','pegawai.id_karyawan')
		->where('pegawai.id_karyawan',$id)->get();
	// passing data pegawai yang didapat ke view edit.blade.php
		return view('edit',['pegawai' => $pegawai]);

	}

	// update data pegawai
	public function update(Request $request)
	{
	// update data pegawai
		DB::table('pegawai')->where('id_karyawan',$request->id)->update([
			'nama' => $request->nama,
			'alamat' => $request->alamat,
			'no_ktp' => $request->no_ktp
		]);

		DB::table('pendidikan')->where('id_karyawan',$request->id)->update([
			'nama_sekolah' => $request->nama_sekolah,
			'jurusan' => $request->jurusan,
			'thn_masuk' => $request->thn_masuk,
			'thn_lulus' => $request->thn_lulus
		]);

		DB::table('pengalaman_kerja')->where('id_karyawan',$request->id)->update([
			'instansi' => $request->instansi,
			'jabatan' => $request->jabatan,
			'tahun' => $request->tahun,
			'keterangan' => $request->keterangan
		]);
	// alihkan halaman ke halaman pegawai
		return redirect('/pegawai');
	}

	// method untuk hapus data pegawai
	public function hapus($id)
	{
	// menghapus data pegawai berdasarkan id yang dipilih
		DB::table('pegawai')->where('id_karyawan',$id)->delete();
		DB::table('pendidikan')->where('id_karyawan',$id)->delete();
		DB::table('pengalaman_kerja')->where('id_karyawan',$id)->delete();
		
	// alihkan halaman ke halaman pegawai
		return redirect('/pegawai');
	}
}